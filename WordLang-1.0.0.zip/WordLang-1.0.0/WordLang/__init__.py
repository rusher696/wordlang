"""
A module if string, wordblob, and NLP data had a baby.
Includes:
    Sentiment - Yes. Sentiment.
    Polarity - ARE YOU BIPOLAR????
    Sentence-ifying - I made up a word for you.
    etc...
    
Regards: The Curious Coder
"""
from .WordLang import WordLang, SimAI
__version__ = "0.0.1"
__all__ = ["WordLang", "SimAI"]
__easter__ = "ONCE AGAIN. FOUND."
def _secret():
    while True:
        print("Thallium, then lead and bismuth for your tummy. Polonium! Astatine would be yummy!")